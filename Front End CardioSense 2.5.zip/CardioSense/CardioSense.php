<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="Css/login.css">
    <link rel="shortcut icon" href="Css\cardioicon.ico" type="image/x-icon">
    <title>CardioSense Login</title>
</head>
<body>
    <div id="pageContent" class="container">
        <img src="Css/logo.png" alt="CardioSense Logo">
        <h1>CARDIOSENSE</h1>
        <p>Precisão em cada batida</p>

        <div class="input-group">
            <i class="icon fas fa-envelope"></i>
            <input type="email" placeholder="Email" id="email">
        </div>
        <div class="input-group">
            <i class="icon fas fa-lock"></i>
            <input type="password" placeholder="Senha" id="password">
            <i class="toggle-password fas fa-eye" title="Visualizar senha" onclick="togglePasswordVisibility()"></i>
        </div>

        <button onclick="login()">Entrar</button>
        
        <a href="javascript:void(0)" class="forgot-password" onclick="openPopup()">Esqueceu a senha?</a>
        <a href="Cadastro.php" class="signup-link">Ainda não tem uma conta? Crie uma agora</a>
    </div>

   
    <div id="popupOverlay" class="popup-overlay"></div>
    <div id="securityPopup" class="popup">
        <span class="close" onclick="closePopup()">&times;</span>
        <h3>Recuperar Senha</h3>
        <p>Responda à pergunta de segurança:</p>
        <label for="securityAnswer">Nome do seu primeiro animal de estimação?</label>
        <input type="text" id="securityAnswer" placeholder="Digite sua resposta">
        <button onclick="validateSecurityAnswer()">Enviar</button>
    </div>

    
    <div id="resetPasswordPopup" class="popup">
        <span class="close" onclick="closePopup()">&times;</span>
        <h3>Redefinir Senha</h3>
        <input type="password" id="newPassword" placeholder="Nova Senha">
        <input type="password" id="confirmPassword" placeholder="Confirme a Nova Senha">
        <button onclick="saveNewPassword()">Salvar Nova Senha</button>
    </div>

    <script src="Js/login.js"></script>
</body>
</html>
