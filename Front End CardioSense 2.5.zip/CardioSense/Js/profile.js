document.getElementById('change-pic').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            document.getElementById('profilePicPreview').src = event.target.result;
        }
        reader.readAsDataURL(file);
    }
});

document.getElementById('calcular-imc').addEventListener('click', function() {
    const altura = parseFloat(document.getElementById('altura').value) / 100;
    const peso = parseFloat(document.getElementById('peso').value);
    if (altura > 0 && peso > 0) {
        const imc = (peso / (altura * altura)).toFixed(2);
        document.getElementById('imc').value = imc;
        document.getElementById('resultado-imc').textContent = 'Seu IMC é: ' + imc;
    } else {
        document.getElementById('resultado-imc').textContent = 'Por favor, insira valores válidos.';
    }
});

// Envio do formulário
document.getElementById('profileForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Dados do perfil enviados (implementação necessária).');
});
