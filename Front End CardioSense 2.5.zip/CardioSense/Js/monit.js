// Simulação de dados para o gráfico em tempo real
let data = [];
let labels = [];

// Função para adicionar novos dados simulados
function addData(chart) {
    const maxDataPoints = 10; // Limitar o número de pontos no gráfico

    // Simulação de batimento cardíaco entre 60 e 100 bpm
    const heartRate = Math.floor(Math.random() * (100 - 60 + 1)) + 60;

    if (data.length >= maxDataPoints) {
        data.shift();
        labels.shift();
    }

    // Adicionar novo dado
    data.push(heartRate);
    const now = new Date();
    labels.push(`${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}`);

    chart.update();
}

// Configuração do gráfico
const ctx = document.getElementById('heartRateChart').getContext('2d');
const heartRateChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: labels,
        datasets: [{
            label: 'Batimentos Cardíacos (BPM)',
            data: data,
            borderColor: '#4c8bf5',
            backgroundColor: 'rgba(76, 139, 245, 0.2)',
            borderWidth: 2,
            tension: 0.3
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: false,
                suggestedMin: 50,
                suggestedMax: 120
            }
        }
    }
});

// Função para atualizar os dados do gráfico periodicamente
setInterval(() => addData(heartRateChart), 1000); // Atualiza a cada segundo


function toggleProfileMenu(event) {
    event.stopPropagation(); 
    const profileMenu = document.getElementById('profileMenu');
    profileMenu.style.display = profileMenu.style.display === 'block' ? 'none' : 'block';
}


document.addEventListener('click', function() {
    const profileMenu = document.getElementById('profileMenu');
    if (profileMenu) {
        profileMenu.style.display = 'none';
    }
});


const btnVoltar = document.getElementById('btnVoltar');
if (btnVoltar) {
    btnVoltar.addEventListener('click', function() {
        window.history.back();
    });
};

// Renderiza as seções acessadas ao carregar a página
document.addEventListener('DOMContentLoaded', () => {
    renderSections(); 
});

// Atualiza as seções acessadas
function updateRecentSections(secao) {
    let sections = JSON.parse(localStorage.getItem('secoes_acessadas')) || [];
    sections = sections.filter(item => item !== secao);
    sections.unshift(secao);
    localStorage.setItem('secoes_acessadas', JSON.stringify(sections));
    renderSections(); // Renderiza a lista após a atualização
}


function handleCardClick(secao, url) {
    updateRecentSections(secao);
    setTimeout(() => {
        window.location.href = url; 
    }, 50);
}

// Renderiza as seções na tela
function renderSections() {
    const sections = JSON.parse(localStorage.getItem('secoes_acessadas')) || [];
    const sectionList = document.getElementById('sectionList');
    if (sectionList) {
        sectionList.innerHTML = ''; // Limpa a lista antes de renderizar
        sections.forEach(secao => {
            const li = document.createElement('li');
            li.textContent = secao;
            sectionList.appendChild(li);
        });
    }
}
