// Inicializa o gráfico
const ctx = document.getElementById('batimentosChart').getContext('2d');
const batimentosChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [],
        datasets: [{
            label: 'Batimentos Cardíacos por Minuto (BPM)',
            data: [],
            backgroundColor: 'rgba(0, 123, 255, 0.2)',
            borderColor: '#007bff',
            borderWidth: 2,
            pointBackgroundColor: '#007bff'
        }]
    },
    options: {
        responsive: true,
        scales: {
            x: {
                title: {
                    display: true,
                    text: 'Tempo (s)',
                    color: '#007bff'
                },
                ticks: {
                    color: '#007bff'
                }
            },
            y: {
                beginAtZero: false,
                title: {
                    display: true,
                    text: 'Batimentos por Minuto (BPM)',
                    color: '#007bff'
                },
                ticks: {
                    color: '#007bff'
                }
            }
        }
    }
});

// Função para consultar o ritmo atual do ESP32
document.getElementById('consultarRitmo').addEventListener('click', function() {
    fetch('http://<IP_DO_SEU_ESP32>/dados') // Substitua pelo IP do seu ESP32
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            const bpm = data.bpm;
            atualizarDados(bpm);
        })
        .catch(error => {
            console.error('Erro ao conectar ao ESP32:', error);
            alert('Não foi possível conectar ao ESP32. Tente novamente.');
        });
});

// Função para atualizar os dados no gráfico
function atualizarDados(bpm) {
    const labels = batimentosChart.data.labels;
    const data = batimentosChart.data.datasets[0].data;
    const timestamp = labels.length; 
    labels.push(timestamp);
    data.push(bpm);

    batimentosChart.update();
}

// Controle do popup
function toggleProfileMenu(event) {
    event.stopPropagation();
    const profileMenu = document.getElementById('profileMenu');
    profileMenu.style.display = profileMenu.style.display === 'block' ? 'none' : 'block';
}


document.addEventListener('click', function() {
    const profileMenu = document.getElementById('profileMenu');
    profileMenu.style.display = 'none';
});


const btnVoltar = document.getElementById('btnVoltar');
if (btnVoltar) {
    btnVoltar.addEventListener('click', function() {
        window.history.back();
    });
}

// Atualiza as seções acessadas
document.addEventListener('DOMContentLoaded', () => {
    const secao = 'Consulta';
    updateRecentSections(secao);
});

function updateRecentSections(secao) {
    let sections = JSON.parse(localStorage.getItem('secoes_acessadas')) || [];
    sections = sections.filter(item => item !== secao);
    sections.unshift(secao);
    localStorage.setItem('secoes_acessadas', JSON.stringify(sections));
}
