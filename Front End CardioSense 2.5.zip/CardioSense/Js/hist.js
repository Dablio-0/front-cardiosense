document.addEventListener('DOMContentLoaded', () => {
    const profileMenu = document.getElementById('profileMenu');
    const btnVoltar = document.getElementById('btnVoltar');

    if (btnVoltar) {
        btnVoltar.addEventListener('click', function() {
            window.history.back();
        });
    }

    const profileButton = document.querySelector('.profile-button');
    if (profileButton) {
        profileButton.addEventListener('click', function(event) {
            event.stopPropagation();
            if (profileMenu) {
                profileMenu.style.display = profileMenu.style.display === 'block' ? 'none' : 'block';
            }
        });
    }

    document.addEventListener('click', function(event) {
        if (profileMenu && !profileMenu.contains(event.target)) {
            profileMenu.style.display = 'none';
        }
    });
// seções
    renderSections(); // Renderiza as seções acessadas ao carregar a página
});

function updateRecentSections(secao) {
    let sections = JSON.parse(localStorage.getItem('secoes_acessadas')) || [];
    sections = sections.filter(item => item !== secao);
    sections.unshift(secao);
    localStorage.setItem('secoes_acessadas', JSON.stringify(sections));
    renderSections(); // Renderiza a lista após a atualização
}

function handleCardClick(secao, url) {
    updateRecentSections(secao);
    setTimeout(() => {
        window.location.href = url; // Redireciona para a nova página
    }, 50);
}

function renderSections() {
    const sections = JSON.parse(localStorage.getItem('secoes_acessadas')) || [];
    const sectionList = document.getElementById('sectionList');
    sectionList.innerHTML = ''; // Limpa a lista antes de renderizar
    sections.forEach(secao => {
        const li = document.createElement('li');
        li.textContent = secao;
        sectionList.appendChild(li);
    });
}
