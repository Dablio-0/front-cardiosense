async function cadastrar() {
    const nome = document.querySelector('input[placeholder="Nome"]').value;
    const email = document.querySelector('input[placeholder="Email"]').value;
    const dataNascimento = document.querySelector('input[type="date"]').value;
    const sexo = document.querySelector('select').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    // Validação simples
    if (!nome || !email || !dataNascimento || !sexo || !password || !confirmPassword) {
        const inputs = [
            { el: 'input[placeholder="Nome"]', field: nome },
            { el: 'input[placeholder="Email"]', field: email },
            { el: 'input[type="date"]', field: dataNascimento },
            { el: 'select', field: sexo },
            { el: 'password', field: password },
            { el: 'confirm-password', field: confirmPassword }
        ];
        
        inputs.forEach(input => {
            if (!input.field) {
                document.querySelector(input.el).classList.add('shake');
            }
        });

        setTimeout(() => {
            inputs.forEach(input => {
                document.querySelector(input.el).classList.remove('shake');
            });
        }, 500);
        
        alert('Por favor, preencha todos os campos.');
        return;
    }

    // Verifica se as senhas correspondem
    if (password !== confirmPassword) {
        alert('As senhas não correspondem.');
        return;
    }

    console.log('Nome:', nome);
    console.log('Email:', email);
    console.log('Data de Nascimento:', dataNascimento);
    console.log('Sexo:', sexo);
    console.log('Senha:', password);

    try {
        // Envia dados para a API
        const response = await fetch('https://sua-api-endpoint.com/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ nome, email,dataNascimento, sexo, password }),
        });

        // Verifica a resposta da API
        if (response.ok) {
            const result = await response.json();
            console.log('Resposta da API:', result);
            alert('Login realizado com sucesso!');
        } else {
            console.error('Erro ao enviar dados para a API:', response.statusText);
            alert('Erro ao realizar login. Verifique suas credenciais.');
        }
    } catch (error) {
        console.error('Erro na comunicação com a API:', error);
        alert('Erro na comunicação com a API.');
    }
}

function togglePasswordVisibility(fieldId, iconElement) {
    const passwordField = document.getElementById(fieldId);
    if (passwordField.type === "password") {
        passwordField.type = "text";
        iconElement.classList.remove("fa-eye");
        iconElement.classList.add("fa-eye-slash");
    } else {
        passwordField.type = "password";
        iconElement.classList.remove("fa-eye-slash");
        iconElement.classList.add("fa-eye");
    }
}
