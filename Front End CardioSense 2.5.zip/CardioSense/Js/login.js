console.log("Loginjs.js carregado"); 

async function login() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    // Validação simples
    if (!email || !password) {
        if (!email) {
            document.getElementById('email').classList.add('shake');
        }
        if (!password) {
            document.getElementById('password').classList.add('shake');
        }
        
        setTimeout(() => {
            document.getElementById('email').classList.remove('shake');
            document.getElementById('password').classList.remove('shake');
        }, 500);
        
        alert('Por favor, preencha todos os campos.');
        return;
    }

   
    console.log('Email:', email);
    console.log('Senha:', password);

    try {
        // Envia dados para a API
        const response = await fetch('https://sua-api-endpoint.com/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });

        // Verifica a resposta da API
        if (response.ok) {
            const result = await response.json();
            console.log('Resposta da API:', result);
            alert('Login realizado com sucesso!');
        } else {
            console.error('Erro ao enviar dados para a API:', response.statusText);
            alert('Erro ao realizar login. Verifique suas credenciais.');
        }
    } catch (error) {
        console.error('Erro na comunicação com a API:', error);
        alert('Erro na comunicação com a API.');
    }
    
}
//-----------------------------Demais funções---------------------------------//
function togglePasswordVisibility() {
    var passwordField = document.getElementById("password");
    var icon = document.querySelector(".toggle-password");
    if (passwordField.type === "password") {
        passwordField.type = "text";
        icon.classList.remove("fa-eye");
        icon.classList.add("fa-eye-slash");
    } else {
        passwordField.type = "password";
        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");
    }
}



function openPopup() {
   
    document.getElementById("popupOverlay").style.display = "block";
    document.getElementById("securityPopup").style.display = "block";
    document.getElementById("pageContent").classList.add("blur-background");
}

function closePopup() {
   
    document.getElementById("popupOverlay").style.display = "none";
    document.getElementById("securityPopup").style.display = "none";
    document.getElementById("resetPasswordPopup").style.display = "none";
    document.getElementById("pageContent").classList.remove("blur-background");
}

function validateSecurityAnswer() {
    var answer = document.getElementById("securityAnswer").value;
    if (answer === "rex") { // Exemplo: resposta correta a ser validada no BD
        alert("Resposta correta! Redefina sua senha.");
        closePopup();
        // Exibe o pop-up para redefinir senha
        document.getElementById("resetPasswordPopup").style.display = "block";
        document.getElementById("popupOverlay").style.display = "block";
    } else {
        alert("Resposta incorreta. Tente novamente.");
    }
}

function saveNewPassword() {
    var newPassword = document.getElementById("newPassword").value;
    var confirmPassword = document.getElementById("confirmPassword").value;

    if (newPassword === confirmPassword) {
        alert("Senha redefinida com sucesso!");
        // Aqui, faça o envio da nova senha para o BD para ser salva
        closePopup();
    } else {
        alert("As senhas não coincidem. Tente novamente.");
    }
}

