<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta de Batimentos - CardioSense</title>
    <link rel="stylesheet" href="Css/cons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="shortcut icon" href="Css/cardioicon.ico" type="image/x-icon">
</head>
<body>
    <header>
        <div class="logo-container">
            <img src="Css/logo.png" alt="CardioSense Logo" class="logo">
            <div class="brand-slogan">
                <span class="brand-name">CardioSense</span>
                <span class="slogan">Precisão em cada batida</span>
            </div>
        </div>
        <div class="header-actions">
            <div class="header-icons">
                <div class="profile-container">
                    <button class="profile-button" title="Perfil" onclick="toggleProfileMenu(event)">
                        <i class="fas fa-user"></i>
                    </button>
                    <div class="profile-menu" id="profileMenu">
                        <a href="perfilusuario.php">Acessar Perfil</a>
                        <a href="CardioSense.php" class="logout-button">Sair</a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main>
        <div class="consulta-container">
            <h2>Consulta de Batimentos Cardíacos</h2>
            <button id="consultarRitmo" class="check-heartbeat-button">Consultar Batimentos</button>
            <div class="graph-container">
                <canvas id="batimentosChart"></canvas>
            </div>
            <button class="btn-voltar" id="btnVoltar">Voltar</button>
        </div>
    </main>
  
    <script src="Js/cons.js"></script>
</body>
</html>
