<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="Css/redef.css">
    <link rel="shortcut icon" href="Css/cardioicon.ico" type="image/x-icon">
    <title>Redefina sua Senha</title>
</head>
<body>
    <div id="pageContent" class="container">
        <img src="Css/logo.png" alt="CardioSense Logo">
        <h1>CARDIOSENSE</h1>
        <p>Precisão em cada batida</p>
        <h4>Recuperar Senha</h4>
        <div class="input-group">
            <input type="email" id="securityAnswer" placeholder="Insira seu Email" required>
        </div>
        <button id="sendButton">Enviar</button>
        <a href="CardioSense.php" class="btn">Voltar</a>
    </div>

    <script src="Js/redef.js"></script>
</body>
</html>
